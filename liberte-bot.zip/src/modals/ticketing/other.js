const { EmbedBuilder, ButtonStyle, ActionRowBuilder, ButtonBuilder, PermissionsBitField } = require('discord.js');



module.exports = {
    id: 'Vrouw',
    permissions: [],
    run: async (client, interaction) => {

    }
};  